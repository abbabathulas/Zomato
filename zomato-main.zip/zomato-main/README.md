 Zomato Home Page 

A simple  Zomato’s homepage created using HTML.

Features
- Static homepage layout
- Basic structure using HTML tags
- Simple and clean code
 Technologies Used
- HTML5

 How to Run
Just open the `index.html` file in any web browser like Chrome.
 Purpose
This project was created to practice basic web development using HTML.
